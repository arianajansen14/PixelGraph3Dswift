//
//  pixelgraphingApp.swift
//  pixelgraphing
//
//  Created by ariana jansen on 02/10/2025.
//

import SwiftUI

@main
struct pixelgraphingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
